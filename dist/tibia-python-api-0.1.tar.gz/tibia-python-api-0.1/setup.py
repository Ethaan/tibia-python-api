from distutils.core import setup
setup(
  name = 'tibia-python-api',
  packages = ['tibia-python-api'],
  version = '0.1',
  description = 'A Tibia easy to use Tibia API',
  author = 'Ethaan Escareno',
  author_email = 'ethan.rosanoo@gmail.com',
  url = 'https://github.com/Ethaan/tibia-python-api',
  keywords = ['tibia', 'api', 'rpg'],
)
